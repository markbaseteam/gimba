---
dg-publish: true
dg-show-tags: true
tags:
  - dg
---
```bash
#!/opt/bin/bash
# Данные сервера
date=`date +'%F %T'`
#Получаем температуры WIFI сетей
tmp=`wl -i eth6 phy_tempsense |awk '{print $1}'
`tmp2=`wl -i eth7 phy_tempsense |awk '{print $1}'
`let "TP = (tmp / 2) + 20"let "TP2 = (tmp2 / 2) + 20"

echo $TP $TP2\#let "CPU = temp5 + temp24"\

```