---
dg-publish: true
dg-home: true
---
# ТЗ по созданию подписи html для почтовых клиентов

Необходимо создать страницу-генератор, которая будет генерировать определенный код html для дальнейшей вставки кода в подпись почтовых клиентов. 
## Описание 

Для создания подписи сотрудник заходит на страницу, где необходимо заполнить поля для генерации подписи, список полей следующий: 

> [!info] Внимание
> Все записи должны быть на **английском языке, не на кирилице** 
1) `Name` - Имя, Фамилия (text)
2) `Position` -Должность (text)
3) `Email` - Адрес почты, полностью (text)
4) `Mobile` - номер мобильного телефона (text)
5) `Website` - Домен, выбрать из списка (svyazcom.ru / soft.sc)
6) `Whatsup` - Ссылка на Whatsup в формате https://wa.me/79029420545, где **79029420545** - номер телефона
7) `Telegram` - Ссылка на Telegram в формате https://t.me/glemag, где **glemag** - никнейм

> [!tip] Важно
> Если вы не хотите афишировать свои мессенджеры - можете оставить поля `Whatsup` `Telegram` пустыми
> 

7) После заполнения полей нажимается кнопка ``"Сгенерировать"``
8) По итогу генерируется html код примерно в таком виде

```html

<!-- signature code start-->
<p style="color:#848484; font-size:9pt; font-family:Verdana; ">

<table border="0" cellpadding="0" cellspacing="0">
    <tbody>
        <tr>
            <td style="vertical-align: top;"> <img src="https://home.glemag.ru/sig/logo_sc.svg" align="top" width="70%" height="70%"></td>
            <td>
                
<font style="color:#848484; font-size:9pt; font-family:Verdana,sans-serif; Verdana; " > 
<font color="#000">Gleb Maginskiy </font><br>
CBDO<br> 
<a style="color: #98AFC7;" href="mailto:glemag@svyazcom.ru">glemag@svyazcom.ru</a><br>
<a style="color: #98AFC7;" href="http://www.svyazcom.ru">www.svyazcom.ru</a><br>
<a style="color: #196F3D; " href="https://wa.me/79029420545"><img src="https://home.glemag.ru/sig/wsp.svg"></a>
<a style="color: #2874A6; " href="https://t.me/glemag"><img src="https://home.glemag.ru/sig/tgr.svg"></a>


            </td>
        </tr>
    </tbody>
</table>
<!-- signature code end-->
```

#dg  






